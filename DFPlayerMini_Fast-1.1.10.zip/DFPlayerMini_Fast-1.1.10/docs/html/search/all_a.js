var searchData=
[
  ['query',['query',['../class_d_f_player_mini___fast.html#a13d369a632f2342573be8f654ef72be6',1,'DFPlayerMini_Fast']]]
];
