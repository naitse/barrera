var searchData=
[
  ['getstatus',['getStatus',['../class_d_f_player_mini___fast.html#ae0287fd8f081234bb59b7fad8784eb30',1,'DFPlayerMini_Fast']]]
];
