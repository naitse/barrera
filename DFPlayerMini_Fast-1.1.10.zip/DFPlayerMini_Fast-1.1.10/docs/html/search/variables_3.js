var searchData=
[
  ['send_5finit',['SEND_INIT',['../namespacedfplayer.html#afb660d5e39f0e8a4d4af2386cad8b306',1,'dfplayer']]],
  ['stack_5fsize',['STACK_SIZE',['../namespacedfplayer.html#ad474fe34d6fe295ddd22215eaa12b4ac',1,'dfplayer']]],
  ['stop_5frepeat',['STOP_REPEAT',['../namespacedfplayer.html#a5db7933fb641455ed1187544f6c204c8',1,'dfplayer']]]
];
