var searchData=
[
  ['vol_5fadjust',['VOL_ADJUST',['../namespacedfplayer.html#aa668203e39350fcdd34494c901319457',1,'dfplayer']]]
];
